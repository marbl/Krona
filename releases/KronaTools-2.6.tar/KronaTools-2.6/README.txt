For installation and usage instructions please refer to:
http://sourceforge.net/p/krona/wiki/KronaTools

Tool names start with 'kt' (use TAB for completions) and can be run without
arguments to list options.

For questions and comments please email:
Brian Ondov <ondovb@nbacc.net>
