For Windows, Microsoft Excel 97 or later is required.
For Mac, Microsoft Excel:Mac 2011 or later is required.

For installation and usage instructions please refer to:
http://sourceforge.net/p/krona/wiki/ExcelTemplate

For questions and comments please email:
Brian Ondov <ondovb@nbacc.net>
